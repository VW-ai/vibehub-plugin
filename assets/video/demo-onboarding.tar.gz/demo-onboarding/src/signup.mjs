// Signup flow for acme-app: users register, verify their email, then reach the dashboard.
import { randomBytes } from "node:crypto";
import { welcomeEmail } from "./welcome.mjs";

export const users = new Map();
export const outbox = [];

export function signup(email) {
  const token = randomBytes(8).toString("hex");
  users.set(email, { email, verified: false, token });
  return { next: "/verify-pending", token };
}

export function verify(email, token) {
  const user = users.get(email);
  if (!user || user.token !== token) return { next: "/verify-pending", verified: false };
  user.verified = true;
  outbox.push(welcomeEmail(user));
  return { next: "/dashboard", verified: true };
}
