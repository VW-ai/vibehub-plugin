export function welcomeEmail(user) {
  return {
    to: user.email,
    subject: "You're in — here's your first step",
    body: "Thanks for verifying. Your dashboard is ready: create your first project, invite a teammate, or import existing work. Reply to this email if anything is unclear.",
  };
}
