export function firstRun(user) {
  if (!user?.verified) throw new Error("dashboard requires a verified user");
  if (user.activity?.length) return [];
  return [
    { id: "create-project", label: "Create your first project" },
    { id: "invite-teammate", label: "Invite a teammate" },
    { id: "import-work", label: "Import existing work" },
  ];
}
