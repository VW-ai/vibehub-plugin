import test from "node:test"; import assert from "node:assert/strict";
import { firstRun } from "../src/dashboard.mjs";
test("first run shows three next steps and no marketing", () => {
  const steps = firstRun({ email: "a@x.io", verified: true, activity: [] });
  assert.equal(steps.length, 3); assert.ok(steps.every((s) => !/marketing/i.test(s.label)));
});
test("unverified users cannot reach the dashboard", () => { assert.throws(() => firstRun({ verified: false })); });
