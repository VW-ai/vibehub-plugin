import test from "node:test"; import assert from "node:assert/strict";
import { signup, verify, users, outbox } from "../src/signup.mjs";
test("signup registers a user", () => { signup("a@x.io"); assert.ok(users.has("a@x.io")); });
test("signup issues a token and leaves the user unverified", () => {
  const { next, token } = signup("b@x.io");
  assert.equal(next, "/verify-pending"); assert.match(token, /^[0-9a-f]{16}$/); assert.equal(users.get("b@x.io").verified, false);
});
test("verify with the issued token routes to the dashboard", () => {
  const { token } = signup("c@x.io");
  assert.deepEqual(verify("c@x.io", token), { next: "/dashboard", verified: true });
});
test("verify with a wrong token leaves the user unverified", () => {
  signup("d@x.io");
  assert.deepEqual(verify("d@x.io", "nope"), { next: "/verify-pending", verified: false });
  assert.equal(users.get("d@x.io").verified, false);
});
test("welcome email is sent only after verification", () => {
  const before = outbox.length; const { token } = signup("e@x.io");
  assert.equal(outbox.length, before); verify("e@x.io", token);
  assert.equal(outbox.length, before + 1); assert.equal(outbox.at(-1).to, "e@x.io");
});
